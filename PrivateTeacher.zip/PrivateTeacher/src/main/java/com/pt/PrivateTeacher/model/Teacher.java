package com.pt.PrivateTeacher.model;

import lombok.Data;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.time.LocalDateTime;


@Entity
@Data
public class Teacher {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idTeacher")
    private Integer idTeacher;

    @Size(max=8)
    @Column(name="dni")
    private Integer dni;

    @Enumerated(EnumType.STRING)
    private Rol rol;
    public enum Rol{
        TEACHER
    }

    @Column(name="name")
    private String name;

    @Column(name="lastName")
    private String lastName;

    @Size(max=9)
    @Column(name="number")
    private Integer number;

    @Column(name="costHour")
    private Double costHour;

    @Column(name="course")
    private String course;



    @Transient
    private MultipartFile photo;

    @Column(name="description")
    private String descriptionPersonal;

    @Column(name="qualification")
    private String qualification;

    @Transient
    private MultipartFile certificates;

    @Email
    @Column(name="email")
    private String email;

    private String password;

    @NotBlank
    @Transient
    private String password1;

    @NotBlank
    @Transient
    private String password2;

    @PrePersist
    @PreUpdate
    void asingarNombreCompleto()
    {
       String nombreCompleto = name + " " + lastName;
    }

}
