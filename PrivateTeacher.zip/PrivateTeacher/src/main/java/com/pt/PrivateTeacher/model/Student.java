package com.pt.PrivateTeacher.model;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Data
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idStudent")
    private Integer idStudent;

    @Size(max=8)
    @Column(name="dni")
    private Integer dni;

    @Enumerated(EnumType.STRING)
    private Teacher.Rol rol;
    public enum Rol{
        STUDENT
    }

    @Column(name="name")
    private String name;

    @Column(name="lastName")
    private String lastName;

    @Size(max=9)
    @Column(name="number")
    private Integer number;

    @Column(name = "age")
    private Integer age;

    @Column(name="levelEnglish")
    private String levelEnglish;

    @Column(name="courseInterest")
    private String courseInterest;

    @Email
    @Column(name="email")
    private String email;

    private String password;

    @NotBlank
    @Transient
    private String password1;

    @NotBlank
    @Transient
    private String password2;

    @PrePersist
    @PreUpdate
    void asingarNombreCompleto()
    {
        String nombreCompleto = name + " " + lastName;
    }
}
