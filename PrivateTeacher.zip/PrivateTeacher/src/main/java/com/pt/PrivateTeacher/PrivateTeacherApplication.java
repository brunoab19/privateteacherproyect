package com.pt.PrivateTeacher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrivateTeacherApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrivateTeacherApplication.class, args);
	}

}
