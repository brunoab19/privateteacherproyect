package com.pt.PrivateTeacher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrivateTeacherApplicationTests {

	@Test
	void contextLoads() {
	}

}
